console.log("🚀 SpotBoard: Content Script Loaded");const R=!1,b=(...t)=>R;let E=!1,m=null,x=[];function P(t){return t?[/^yui_/i,/\d{10,}/,/[a-f0-9]{8}-[a-f0-9]{4}/i,/^react-/i,/^__BVID__/i,/^ember\d+/i].some(o=>o.test(t)):!1}function $(t){if(b("🎯 Starting selector generation for:",t.tagName,t.className),t.id&&!P(t.id))return b("✅ Found stable ID selector:",`#${t.id}`),`#${t.id}`;t.id&&P(t.id)&&b("⚠️ Skipping auto-generated ID:",t.id);let e=T(t);const o=document.querySelectorAll(e);if(b(`🔍 Base selector matches ${o.length} elements`),o.length===1)return e;b(`⚠️ Selector "${e}" matches ${o.length} elements, adding context...`),e===t.tagName.toLowerCase()&&o.length>50;const s=t.parentElement;if(s){const a=Array.from(s.children).filter(h=>h.matches(e.split("[")[0])).indexOf(t)+1;if(a>0){const h=`${e}:nth-of-type(${a})`,v=document.querySelectorAll(h);if(b(`🔍 nth-of-type selector matches ${v.length} elements`),v.length===1)return h}}const i=U(t,e);if(i)return i;if(/^[a-z]+$/i.test(e)){const l=t.parentElement;if(l)return`${T(l)} > ${e}`}return e}function q(t){return t.replace(/:/g,"\\:").replace(/\//g,"\\/").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/\(/g,"\\(").replace(/\)/g,"\\)").replace(/\./g,"\\.").replace(/#/g,"\\#").replace(/!/g,"\\!").replace(/@/g,"\\@").replace(/\$/g,"\\$").replace(/%/g,"\\%").replace(/\^/g,"\\^").replace(/&/g,"\\&").replace(/\*/g,"\\*").replace(/\+/g,"\\+").replace(/=/g,"\\=").replace(/,/g,"\\,").replace(/</g,"\\<").replace(/>/g,"\\>").replace(/\?/g,"\\?").replace(/~/g,"\\~")}function T(t){let e=t.tagName.toLowerCase();if(t.classList.length>0){const s=Array.from(t.classList).filter(i=>!i.includes("hover")&&!i.includes("active")).slice(0,3).map(i=>q(i));s.length>0&&(e+="."+s.join("."))}const o=["data-testid","data-test","data-component","data-section","data-module","data-type","data-t","role"];for(const s of o)if(t.hasAttribute(s)){const i=t.getAttribute(s);e+=`[${s}="${i}"]`;break}return e}function U(t,e){let o=t.parentElement;const s=[e];for(;o&&o.tagName!=="BODY"&&o.tagName!=="HTML";){if(o.id){s.unshift(`#${o.id}`);const a=s.join(" > ");if(document.querySelectorAll(a).length===1)return a}const i=["data-testid","data-component","data-section","data-module","data-type"];for(const a of i)if(o.hasAttribute(a)){const h=`${o.tagName.toLowerCase()}[${a}="${o.getAttribute(a)}"]`;s.unshift(h);const v=s.join(" > ");if(document.querySelectorAll(v).length===1)return v;s.shift()}const p=T(o);s.unshift(p);const l=s.join(" > ");if(document.querySelectorAll(l).length===1)return l;if(s.length>4)break;o=o.parentElement}return null}function N(t){if(!E)return;const e=t.target;if(!e.closest("#spotboard-capture-confirmation")){if(m){m.style.setProperty("outline","5px solid #00ff00","important"),m.contains(e)&&e!==m&&(x.includes(e)?(e.style.setProperty("background","rgba(255, 0, 0, 0.3)","important"),e.style.setProperty("outline","2px solid #ff0000","important")):(e.style.setProperty("outline","2px dashed #ff0000","important"),e.style.setProperty("background","transparent","important")),e.style.cursor="pointer");return}e.style.setProperty("outline","5px solid red","important"),e.style.cursor="crosshair",t.stopPropagation()}}function B(t){if(!E)return;const e=t.target;if(!e.closest("#spotboard-capture-confirmation")){if(m){if(e===m||x.includes(e))return;e.style.removeProperty("outline"),e.style.removeProperty("background");return}e.style.outline=""}}function L(t,e="success"){const o=document.createElement("div");o.style.cssText=`
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    background: rgba(0, 0, 0, 0.5) !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    z-index: 2147483647 !important;
    isolation: isolate !important;
  `;const s=document.createElement("div"),i=e==="success"?"#2d3748":"#742a2a";s.style.cssText=`
    background: ${i} !important;
    color: white !important;
    padding: 24px !important;
    border-radius: 8px !important;
    max-width: 400px !important;
    width: 90% !important;
    text-align: center !important;
    position: relative !important;
    z-index: 2147483647 !important;
  `,s.innerHTML=`
    <div style="font-size: 16px; margin-bottom: 20px; line-height: 1.5;">
      ${t}
    </div>
    <button id="closeNotification" style="width: 100%; padding: 12px; background: #4299e1; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; font-weight: 600;">
      OK
    </button>
  `,o.appendChild(s),document.body.appendChild(o);const p=o.querySelector("#closeNotification");p&&p.addEventListener("click",()=>o.remove()),o.addEventListener("click",l=>{l.target===o&&o.remove()})}function W(t,e=[]){console.log("🧹 sanitizeHTML called with",e.length,"excluded elements");const o=[t,...Array.from(t.querySelectorAll("*"))],s=[],i=t.getBoundingClientRect(),p=r=>{let n=r.parentElement;for(;n&&n!==t;){const d=window.getComputedStyle(n),f=d.overflowX,c=d.overflow;if(c==="hidden"||c==="scroll"||c==="auto"||c==="clip"||f==="hidden"||f==="scroll"||f==="auto"||f==="clip"){const y=n.getBoundingClientRect();if(y.width<i.width&&y.width>50)return y}n=n.parentElement}return i};o.forEach(r=>{if(r instanceof HTMLElement&&r!==t){const n=window.getComputedStyle(r),d=n.display==="none",f=n.visibility==="hidden",c=n.opacity==="0",u=r.getAttribute("aria-hidden")==="true",y=r.getBoundingClientRect(),w=p(r),g=y.right<w.left,C=y.left>w.right;(d||f||c||u||(g||C))&&(r.setAttribute("data-spotboard-hidden","true"),s.push(r))}}),t.querySelectorAll("img").forEach(r=>{try{let n=r.closest("article, section")||r.parentElement;if(!n){console.log("  ⚠️ Image has no container, defaulting to icon"),r.setAttribute("data-scale-context","icon");return}const d=n.getBoundingClientRect(),f=d.width*d.height,c=r.getBoundingClientRect(),u=c.width*c.height,y=c.height,w=f>0?u/f:0;let g;y<40||u<1600?g="icon":y<70||u<4900||w<.1?g="small":w<.25||u<15e3?g="thumbnail":w<.5||u<4e4?g="medium":g="preview",r.setAttribute("data-scale-context",g)}catch(n){console.warn("  ⚠️ Failed to classify image, defaulting to icon:",n),r.setAttribute("data-scale-context","icon")}});const l=t.cloneNode(!0);s.forEach(r=>r.removeAttribute("data-spotboard-hidden")),e.length>0&&(console.log("🎯 Processing",e.length,"user-excluded elements"),e.forEach(r=>{const n=_(r,t);console.log("  📍 Excluded element path:",n,r.tagName,r.className);const d=D(l,n);d?(d.remove(),console.log("  ✅ Removed excluded element from clone")):console.warn("  ⚠️ Could not find excluded element in clone")})),[".visually-hidden",".sr-only",'[class*="VisuallyHidden"]','[class*="MobileValue"]','[class*="-mobile"]','[class*="mobile-"]','[class*="-short"]','[class*="short-"]','[class*="team-name--short"]','[class*="team-name--abbr"]','[class*="-abbr"]','[class*="abbreviated"]','[class*="navigate"]','[class*="NavigateButton"]','[class*="previousButton"]','[class*="nextButton"]','[class*="prevButton"]','[class*="Chevron"]','[class*="chevron"]','[class*="carousel-control"]','[class*="slick-arrow"]','[class*="swiper-button"]','[class*="gallery-nav"]','[class*="slider-nav"]','[class*="slide-arrow"]','button[aria-label*="previous"]','button[aria-label*="next"]','button[aria-label*="arrow"]','[class*="ImageControls"]','[class*="image-controls"]','[class*="Controls_"]'].forEach(r=>{l.querySelectorAll(r).forEach(n=>n.remove())}),l.querySelectorAll('[data-spotboard-hidden="true"]').forEach(r=>r.remove()),[l,...Array.from(l.querySelectorAll("*"))].forEach(r=>{r instanceof HTMLElement&&(r.style.removeProperty("cursor"),r.style.removeProperty("outline"),r.style.length===0&&r.removeAttribute("style"))}),l.querySelectorAll("img").forEach(r=>{r.removeAttribute("loading"),["blurring","skeleton","loading","placeholder","lazy","lazy-load"].forEach(d=>{r.classList.contains(d)&&r.classList.remove(d)})}),l.querySelectorAll("img").forEach(r=>{const n=["data-image","data-src","data-lazy-src","data-original","data-lazy"];for(const d of n){const f=r.getAttribute(d);if(f&&f.startsWith("http")){r.setAttribute("src",f);break}}});const S=window.location.href;return l.querySelectorAll("img[src]").forEach(r=>{const n=r.getAttribute("src");if(n&&n.startsWith("//")){r.setAttribute("src","https:"+n);return}if(n&&!n.startsWith("http")&&!n.startsWith("data:")&&!n.startsWith("blob:"))try{const d=new URL(n,S).href;r.setAttribute("src",d)}catch(d){console.warn("  ⚠️ Could not fix img src:",n,d)}}),l.querySelectorAll("img[srcset]").forEach(r=>{const n=r.getAttribute("srcset");if(n)try{const d=n.split(",").map(f=>{const c=f.trim().split(/\s+/),u=c[0];if(u&&u.startsWith("//"))return c[0]="https:"+u,c.join(" ");if(u&&!u.startsWith("http")&&!u.startsWith("data:")&&!u.startsWith("blob:")){const y=new URL(u,S).href;c[0]=y}return c.join(" ")}).join(", ");r.setAttribute("srcset",d)}catch(d){console.warn("  ⚠️ Could not fix img srcset:",d)}}),l.querySelectorAll("a[href]").forEach(r=>{const n=r.getAttribute("href");if(n&&!n.startsWith("#")&&!n.startsWith("javascript:")&&!n.startsWith("mailto:")&&!n.startsWith("tel:")&&!n.startsWith("http"))try{const d=new URL(n,S).href;r.setAttribute("href",d)}catch(d){console.warn("  ⚠️ Could not fix link href:",n,d)}}),l.querySelectorAll("[style]").forEach(r=>{const n=r.getAttribute("style");if(n&&n.includes("url("))try{const d=n.replace(/url\(['"]?([^'"()]+)['"]?\)/g,(f,c)=>{if(c.startsWith("data:")||c.startsWith("blob:")||c.startsWith("http"))return f;try{return`url('${new URL(c,S).href}')`}catch{return f}});r.setAttribute("style",d)}catch(d){console.warn("  ⚠️ Could not fix CSS background:",d)}}),l.outerHTML}function _(t,e){const o=[];let s=t;for(;s&&s!==e;){const i=s.parentElement;if(!i)break;const p=Array.from(i.children).indexOf(s);o.unshift(p),s=i}return o}function D(t,e){let o=t;for(const s of e){if(!o)return null;o=o.children[s]||null}return o}function k(){x.forEach(t=>{t.style.removeProperty("background"),t.style.removeProperty("outline")}),x=[]}function I(t){if(x.includes(t))x=x.filter(o=>o!==t),t.style.removeProperty("background"),t.style.removeProperty("outline"),b("✅ Element un-excluded:",t.tagName,t.className);else{const o=$(t);if(/^[a-z]+$/i.test(o.trim())){const a=document.createElement("div");a.style.cssText=`
        position: absolute;
        background: #f56565;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        z-index: 999998;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        pointer-events: none;
      `,a.textContent="⚠️ Too generic - will be skipped!";const h=t.getBoundingClientRect();a.style.left=`${h.left+window.scrollX}px`,a.style.top=`${h.top+window.scrollY-40}px`,document.body.appendChild(a),setTimeout(()=>a.remove(),3e3)}const i=/^H[1-6]$/i.test(t.tagName),p=t.className&&(t.className.includes("heading")||t.className.includes("title")||t.className.includes("header")),l=t.hasAttribute("data-testid")&&(t.getAttribute("data-testid")?.includes("heading")||t.getAttribute("data-testid")?.includes("title"));if(i||p||l){const a=document.createElement("div");a.style.cssText=`
        position: absolute;
        background: #f59e0b;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        z-index: 999998;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        pointer-events: none;
        max-width: 280px;
        line-height: 1.4;
      `,a.innerHTML="⚠️ Excluding heading may affect refresh.<br>Keep section labels for best results.";const h=t.getBoundingClientRect();a.style.left=`${h.left+window.scrollX}px`,a.style.top=`${h.top+window.scrollY-60}px`,document.body.appendChild(a),setTimeout(()=>a.remove(),4e3)}x.push(t),t.style.setProperty("background","rgba(255, 0, 0, 0.3)","important"),t.style.setProperty("outline","2px solid #ff0000","important"),b("❌ Element excluded:",t.tagName,t.className)}}function H(t){if(!E)return;b("🖱️ Click detected on:",t.target);const e=t.target;if(e.closest("#spotboard-capture-confirmation"))return;if(m){if(m.contains(e)&&e!==m){t.preventDefault(),t.stopPropagation(),I(e);return}return}t.preventDefault(),t.stopPropagation(),b("🎯 Target element:",e.tagName,e.className),m=e,e.style.setProperty("outline","5px solid #00ff00","important");let o="";if(/^H[1-6]$/i.test(e.tagName)){const i=e.textContent?.trim();i&&(o=i.length>50?i.substring(0,50)+"...":i)}if(!o){const i=e.querySelector("h1, h2, h3, h4, h5, h6");if(i?.textContent?.trim()){const p=i.textContent.trim();o=p.length>50?p.substring(0,50)+"...":p}}if(!o){const p=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:l=>{const a=l.textContent?.trim();return a&&a.length>0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}}).nextNode();if(p?.textContent?.trim()){const l=p.textContent.trim();o=l.length>50?l.substring(0,50)+"...":l}}o||(o=`Spot from ${window.location.hostname}`);const s=$(e);try{M(e,o,s),b("✅ showCaptureConfirmation returned")}catch(i){console.error("❌ showCaptureConfirmation FAILED:",i)}}function M(t,e,o){const s=document.createElement("div");s.id="spotboard-capture-confirmation",s.style.cssText=`
    position: fixed !important;
    top: 20px !important;
    right: 20px !important;
    background: #6b46c1 !important;
    color: white !important;
    padding: 20px !important;
    border-radius: 12px !important;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1) !important;
    z-index: 2147483647 !important;
    min-width: 300px !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
    isolation: isolate !important;
  `,s.innerHTML=`
    <div style="margin-bottom: 16px;">
      <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">
        ✅ Captured: ${e}
      </div>
      <div style="font-size: 14px; opacity: 0.9;">
        Click elements inside the green box to exclude them.<br>
        They'll turn red. Click again to undo.
      </div>
    </div>
    <div style="display: flex; gap: 8px;">
      <button id="confirmSpot" style="flex: 1; padding: 12px; background: #48bb78; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
        Confirm Spot
      </button>
      <button id="cancelSpot" style="flex: 1; padding: 12px; background: #f56565; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
        Cancel
      </button>
    </div>
  `,document.body.appendChild(s);const i=s.querySelector("#confirmSpot");i&&i.addEventListener("click",a=>{a.stopPropagation(),a.preventDefault(),s.remove(),setTimeout(()=>{const h=[];x.forEach(g=>{const C=$(g);h.push(C)}),console.log("🎯 Generated",h.length,"exclusion selectors");const v=W(t,x);b("🧹 HTML sanitized, length:",v.length,"chars");const r=t.querySelector(`
          h1, h2, h3, h4,
          [class*="heading"], [class*="title"], [class*="header"],
          [data-testid*="heading"], [data-testid*="title"]
        `)?.textContent?.trim()||null,n=r?r.substring(0,100):null,f=`https://www.google.com/s2/favicons?sz=64&domain=${new URL(window.location.href).hostname}`,c={id:crypto.randomUUID(),url:window.location.href,selector:o,name:e,html_cache:v,last_refresh:new Date().toISOString(),favicon:f},u={url:c.url,name:c.name,favicon:c.favicon,customLabel:void 0,selector:c.selector,headingFingerprint:n};console.log("💾 Storing metadata in sync storage (~300 bytes), exclusions in local storage");const w={[`comp-${c.id}`]:{id:c.id,name:u.name,url:u.url,favicon:u.favicon,customLabel:u.customLabel,selector:u.selector,headingFingerprint:u.headingFingerprint,excludedSelectors:h,last_refresh:c.last_refresh}};chrome.storage.sync.set(w,()=>{if(chrome.runtime.lastError){console.error("❌ Sync storage set error:",chrome.runtime.lastError),L(`❌ Save failed: ${chrome.runtime.lastError.message}`,"error");return}chrome.storage.local.get(["componentsData"],g=>{const C=g.componentsData||{};C[c.id]={selector:c.selector,html_cache:c.html_cache,last_refresh:c.last_refresh,excludedSelectors:h},chrome.storage.local.set({componentsData:C},()=>{if(chrome.runtime.lastError){console.error("❌ Local storage set error:",chrome.runtime.lastError),L(`❌ Save failed: ${chrome.runtime.lastError.message}`,"error");return}t.style.outline="",t.style.cursor="",m=null,k(),L(`✅ Saved: ${e}`,"success"),A(!1)})})})},2e3)},!0);const p=s.querySelector("#cancelSpot");p&&p.addEventListener("click",a=>{a.stopPropagation(),a.preventDefault(),s.remove(),t.style.outline="",t.style.cursor="",m=null,k(),A(!1)},!0);const l=a=>{a.key==="Escape"&&(s.remove(),t.style.outline="",t.style.cursor="",m=null,k(),document.removeEventListener("keydown",l))};document.addEventListener("keydown",l)}function z(t){t.key==="Escape"&&E&&(A(!1),alert("❌ Capture Cancelled"))}function A(t){E=t!==void 0?t:!E,E?(document.addEventListener("mouseover",N,!0),document.addEventListener("mouseout",B,!0),document.addEventListener("click",H,!0),document.addEventListener("keydown",z,!0)):(document.removeEventListener("mouseover",N,!0),document.removeEventListener("mouseout",B,!0),document.removeEventListener("click",H,!0),document.removeEventListener("keydown",z,!0),document.querySelectorAll("*").forEach(e=>{e.style.outline="",e.style.cursor=""}))}chrome.runtime.onMessage.addListener((t,e,o)=>{(t.message==="TOGGLE_CAPTURE"||t.type==="TOGGLE_CAPTURE")&&A()});

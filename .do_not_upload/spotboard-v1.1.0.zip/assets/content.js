console.log("🚀 SpotBoard: Content Script Loaded");const W=!1,x=(...t)=>W;let A=!1,v=null,E=[];function q(t){return t?[/^yui_/i,/\d{10,}/,/[a-f0-9]{8}-[a-f0-9]{4}/i,/^react-/i,/^__BVID__/i,/^ember\d+/i].some(n=>n.test(t)):!1}function z(t){if(x("🎯 Starting selector generation for:",t.tagName,t.className),t.id&&!q(t.id))return x("✅ Found stable ID selector:",`#${t.id}`),`#${t.id}`;t.id&&q(t.id)&&x("⚠️ Skipping auto-generated ID:",t.id);let e=H(t);const n=document.querySelectorAll(e);if(x(`🔍 Base selector matches ${n.length} elements`),n.length===1)return e;x(`⚠️ Selector "${e}" matches ${n.length} elements, adding context...`);const a=t.closest("td, th");if(a){const i=a.cellIndex;if(i!==void 0&&i>=0){const l=a.tagName.toLowerCase(),g=t.parentElement===a?" > ":" ",o=`${l}:nth-child(${i+1})${g}${e}`,r=document.querySelectorAll(o);if(x(`🔍 Table column selector matches ${r.length} elements`),r.length<=n.length)return o}}e===t.tagName.toLowerCase()&&n.length>50;const s=t.parentElement;if(s){const l=Array.from(s.children).filter(m=>m.matches(e.split("[")[0])).indexOf(t)+1;if(l>0){const m=`${e}:nth-of-type(${l})`,g=document.querySelectorAll(m);if(x(`🔍 nth-of-type selector matches ${g.length} elements`),g.length===1)return m}}const f=j(t,e);if(f)return f;if(/^[a-z]+$/i.test(e)){const i=t.parentElement;if(i)return`${H(i)} > ${e}`}return e}function O(t){return t.replace(/:/g,"\\:").replace(/\//g,"\\/").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/\(/g,"\\(").replace(/\)/g,"\\)").replace(/\./g,"\\.").replace(/#/g,"\\#").replace(/!/g,"\\!").replace(/@/g,"\\@").replace(/\$/g,"\\$").replace(/%/g,"\\%").replace(/\^/g,"\\^").replace(/&/g,"\\&").replace(/\*/g,"\\*").replace(/\+/g,"\\+").replace(/=/g,"\\=").replace(/,/g,"\\,").replace(/</g,"\\<").replace(/>/g,"\\>").replace(/\?/g,"\\?").replace(/~/g,"\\~")}function H(t){let e=t.tagName.toLowerCase();if(t.classList.length>0){const a=Array.from(t.classList).filter(s=>!s.includes("hover")&&!s.includes("active")).slice(0,3).map(s=>O(s));a.length>0&&(e+="."+a.join("."))}const n=["data-testid","data-test","data-component","data-section","data-module","data-type","data-t","role"];for(const a of n)if(t.hasAttribute(a)){const s=t.getAttribute(a);e+=`[${a}="${s}"]`;break}return e}function j(t,e){let n=t.parentElement;const a=[e];for(;n&&n.tagName!=="BODY"&&n.tagName!=="HTML";){if(n.id){a.unshift(`#${n.id}`);const i=a.join(" > ");if(document.querySelectorAll(i).length===1)return i}const s=["data-testid","data-component","data-section","data-module","data-type"];for(const i of s)if(n.hasAttribute(i)){const l=`${n.tagName.toLowerCase()}[${i}="${n.getAttribute(i)}"]`;a.unshift(l);const m=a.join(" > ");if(document.querySelectorAll(m).length===1)return m;a.shift()}const f=H(n);a.unshift(f);const d=a.join(" > ");if(document.querySelectorAll(d).length===1)return d;if(a.length>4)break;n=n.parentElement}return null}function D(t){if(!A)return;const e=t.target;if(!e.closest("[data-spotboard-ignore]")&&!e.closest("#spotboard-capture-confirmation")){if(v){v.style.setProperty("outline","5px solid #00ff00","important"),v.contains(e)&&e!==v&&(E.includes(e)?(e.style.setProperty("background","rgba(255, 0, 0, 0.3)","important"),e.style.setProperty("outline","2px solid #ff0000","important")):(e.style.setProperty("outline","2px dashed #ff0000","important"),e.style.setProperty("background","transparent","important")),e.style.cursor="pointer");return}e.style.setProperty("outline","5px solid red","important"),e.style.cursor="crosshair",t.stopPropagation()}}function R(t){if(!A)return;const e=t.target;if(!e.closest("[data-spotboard-ignore]")&&!e.closest("#spotboard-capture-confirmation")){if(v){if(e===v||E.includes(e))return;e.style.removeProperty("outline"),e.style.removeProperty("background");return}e.style.outline=""}}function k(t,e="success"){const n=document.createElement("div");n.style.cssText=`
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    background: rgba(0, 0, 0, 0.5) !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    z-index: 2147483647 !important;
    isolation: isolate !important;
  `;const a=document.createElement("div"),s=e==="success"?"#2d3748":"#742a2a";a.style.cssText=`
    background: ${s} !important;
    color: white !important;
    padding: 24px !important;
    border-radius: 8px !important;
    max-width: 400px !important;
    width: 90% !important;
    text-align: center !important;
    position: relative !important;
    z-index: 2147483647 !important;
  `,a.innerHTML=`
    <div style="font-size: 16px; margin-bottom: 20px; line-height: 1.5;">
      ${t}
    </div>
    <button id="closeNotification" style="width: 100%; padding: 12px; background: #4299e1; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; font-weight: 600;">
      OK
    </button>
  `,n.appendChild(a),document.body.appendChild(n);const f=n.querySelector("#closeNotification");f&&f.addEventListener("click",()=>n.remove()),n.addEventListener("click",d=>{d.target===n&&n.remove()})}function G(t,e=[]){console.log("🧹 sanitizeHTML called with",e.length,"excluded elements");const n=[t,...Array.from(t.querySelectorAll("*"))],a=[],s=t.getBoundingClientRect(),f=o=>{let r=o.parentElement;for(;r&&r!==t;){const c=window.getComputedStyle(r),u=c.overflowX,p=c.overflow;if(p==="hidden"||p==="scroll"||p==="auto"||p==="clip"||u==="hidden"||u==="scroll"||u==="auto"||u==="clip"){const y=r.getBoundingClientRect();if(y.width<s.width&&y.width>50)return y}r=r.parentElement}return s};n.forEach(o=>{if(o instanceof HTMLElement&&o!==t){const r=window.getComputedStyle(o),c=r.display==="none",u=r.visibility==="hidden",p=r.opacity==="0",h=o.getAttribute("aria-hidden")==="true",y=o.getBoundingClientRect(),C=f(o),w=y.right<C.left,$=y.left>C.right;(c||u||p||h||(w||$))&&(o.setAttribute("data-spotboard-hidden","true"),a.push(o))}}),t.querySelectorAll("img").forEach(o=>{try{let r=o.closest("article, section")||o.parentElement;if(!r){console.log("  ⚠️ Image has no container, defaulting to icon"),o.setAttribute("data-scale-context","icon");return}const c=r.getBoundingClientRect(),u=c.width*c.height,p=o.getBoundingClientRect(),h=p.width*p.height,y=p.height,C=u>0?h/u:0;let w;y<40||h<1600?w="icon":y<70||h<4900||C<.1?w="small":C<.25||h<15e3?w="thumbnail":C<.5||h<4e4?w="medium":w="preview",o.setAttribute("data-scale-context",w)}catch(r){console.warn("  ⚠️ Failed to classify image, defaulting to icon:",r),o.setAttribute("data-scale-context","icon")}});const d=t.cloneNode(!0);a.forEach(o=>o.removeAttribute("data-spotboard-hidden")),e.length>0&&(console.log("🎯 Processing",e.length,"user-excluded elements"),e.forEach(o=>{const r=K(o,t);console.log("  📍 Excluded element path:",r,o.tagName,o.className);const c=V(d,r);c?(c.remove(),console.log("  ✅ Removed excluded element from clone")):console.warn("  ⚠️ Could not find excluded element in clone")})),[".visually-hidden",".sr-only",'[class*="VisuallyHidden"]','[class*="MobileValue"]','[class*="-mobile"]','[class*="mobile-"]','[class*="-short"]','[class*="short-"]','[class*="team-name--short"]','[class*="team-name--abbr"]','[class*="-abbr"]','[class*="abbreviated"]','[class*="navigate"]','[class*="NavigateButton"]','[class*="previousButton"]','[class*="nextButton"]','[class*="prevButton"]','[class*="Chevron"]','[class*="chevron"]','[class*="carousel-control"]','[class*="slick-arrow"]','[class*="swiper-button"]','[class*="gallery-nav"]','[class*="slider-nav"]','[class*="slide-arrow"]','button[aria-label*="previous"]','button[aria-label*="next"]','button[aria-label*="arrow"]','[class*="ImageControls"]','[class*="image-controls"]','[class*="Controls_"]'].forEach(o=>{d.querySelectorAll(o).forEach(r=>r.remove())}),d.querySelectorAll('[data-spotboard-hidden="true"]').forEach(o=>o.remove()),[d,...Array.from(d.querySelectorAll("*"))].forEach(o=>{o instanceof HTMLElement&&(o.style.removeProperty("cursor"),o.style.removeProperty("outline"),o.style.length===0&&o.removeAttribute("style"))}),d.querySelectorAll("img").forEach(o=>{o.removeAttribute("loading"),["blurring","skeleton","loading","placeholder","lazy","lazy-load"].forEach(c=>{o.classList.contains(c)&&o.classList.remove(c)})}),d.querySelectorAll("img").forEach(o=>{const r=["data-image","data-src","data-lazy-src","data-original","data-lazy"];for(const c of r){const u=o.getAttribute(c);if(u&&u.startsWith("http")){o.setAttribute("src",u);break}}});const g=window.location.href;return d.querySelectorAll("img[src]").forEach(o=>{const r=o.getAttribute("src");if(r&&r.startsWith("//")){o.setAttribute("src","https:"+r);return}if(r&&!r.startsWith("http")&&!r.startsWith("data:")&&!r.startsWith("blob:"))try{const c=new URL(r,g).href;o.setAttribute("src",c)}catch(c){console.warn("  ⚠️ Could not fix img src:",r,c)}}),d.querySelectorAll("img[srcset]").forEach(o=>{const r=o.getAttribute("srcset");if(r)try{const c=r.split(",").map(u=>{const p=u.trim().split(/\s+/),h=p[0];if(h&&h.startsWith("//"))return p[0]="https:"+h,p.join(" ");if(h&&!h.startsWith("http")&&!h.startsWith("data:")&&!h.startsWith("blob:")){const y=new URL(h,g).href;p[0]=y}return p.join(" ")}).join(", ");o.setAttribute("srcset",c)}catch(c){console.warn("  ⚠️ Could not fix img srcset:",c)}}),d.querySelectorAll("a[href]").forEach(o=>{const r=o.getAttribute("href");if(r&&!r.startsWith("#")&&!r.startsWith("javascript:")&&!r.startsWith("mailto:")&&!r.startsWith("tel:")&&!r.startsWith("http"))try{const c=new URL(r,g).href;o.setAttribute("href",c)}catch(c){console.warn("  ⚠️ Could not fix link href:",r,c)}}),d.querySelectorAll("[style]").forEach(o=>{const r=o.getAttribute("style");if(r&&r.includes("url("))try{const c=r.replace(/url\(['"]?([^'"()]+)['"]?\)/g,(u,p)=>{if(p.startsWith("data:")||p.startsWith("blob:")||p.startsWith("http"))return u;try{return`url('${new URL(p,g).href}')`}catch{return u}});o.setAttribute("style",c)}catch(c){console.warn("  ⚠️ Could not fix CSS background:",c)}}),d.outerHTML}function K(t,e){const n=[];let a=t;for(;a&&a!==e;){const s=a.parentElement;if(!s)break;const f=Array.from(s.children).indexOf(a);n.unshift(f),a=s}return n}function V(t,e){let n=t;for(const a of e){if(!n)return null;n=n.children[a]||null}return n}function B(){E.forEach(t=>{t.style.removeProperty("background"),t.style.removeProperty("outline")}),E=[]}function X(t){if(E.includes(t))E=E.filter(n=>n!==t),t.style.removeProperty("background"),t.style.removeProperty("outline"),x("✅ Element un-excluded:",t.tagName,t.className);else{const n=z(t);if(/^[a-z]+$/i.test(n.trim())){const i=document.createElement("div");i.style.cssText=`
        position: absolute;
        background: #f56565;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        z-index: 999998;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        pointer-events: none;
      `,i.textContent="⚠️ Too generic - will be skipped!";const l=t.getBoundingClientRect();i.style.left=`${l.left+window.scrollX}px`,i.style.top=`${l.top+window.scrollY-40}px`,document.body.appendChild(i),setTimeout(()=>i.remove(),3e3)}const s=/^H[1-6]$/i.test(t.tagName),f=t.className&&(t.className.includes("heading")||t.className.includes("title")||t.className.includes("header")),d=t.hasAttribute("data-testid")&&(t.getAttribute("data-testid")?.includes("heading")||t.getAttribute("data-testid")?.includes("title"));if(s||f||d){const i=document.createElement("div");i.style.cssText=`
        position: absolute;
        background: #f59e0b;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        z-index: 999998;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        pointer-events: none;
        max-width: 280px;
        line-height: 1.4;
      `,i.innerHTML="⚠️ Excluding heading may affect refresh.<br>Keep section labels for best results.";const l=t.getBoundingClientRect();i.style.left=`${l.left+window.scrollX}px`,i.style.top=`${l.top+window.scrollY-60}px`,document.body.appendChild(i),setTimeout(()=>i.remove(),4e3)}E.push(t),t.style.setProperty("background","rgba(255, 0, 0, 0.3)","important"),t.style.setProperty("outline","2px solid #ff0000","important"),x("❌ Element excluded:",t.tagName,t.className)}}function M(t){if(!A)return;x("🖱️ Click detected on:",t.target);const e=t.target;if(e.closest("[data-spotboard-ignore]")||e.closest("#spotboard-capture-confirmation"))return;if(v){if(v.contains(e)&&e!==v){t.preventDefault(),t.stopPropagation(),X(e);return}return}t.preventDefault(),t.stopPropagation(),x("🎯 Target element:",e.tagName,e.className),v=e,e.style.setProperty("outline","5px solid #00ff00","important");let n="";if(/^H[1-6]$/i.test(e.tagName)){const l=e.textContent?.trim();l&&(n=l.length>50?l.substring(0,50)+"...":l)}if(!n){const l=e.querySelector("h1, h2, h3, h4, h5, h6");if(l?.textContent?.trim()){const m=l.textContent.trim();n=m.length>50?m.substring(0,50)+"...":m}}if(!n){const m=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:g=>{const o=g.textContent?.trim();return o&&o.length>0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}}).nextNode();if(m?.textContent?.trim()){const g=m.textContent.trim();n=g.length>50?g.substring(0,50)+"...":g}}n||(n=`Spot from ${window.location.hostname}`);const a=z(e),i=!!!(e.querySelector(`
    h1, h2, h3, h4, caption,
    [class*="heading"], [class*="title"], [class*="header"],
    [data-testid*="heading"], [data-testid*="title"]
  `)?.textContent?.trim()||null);try{Y(e,n,a,i),x("✅ showCaptureConfirmation returned")}catch(l){console.error("❌ showCaptureConfirmation FAILED:",l)}}function Y(t,e,n,a){const s=document.createElement("div");s.id="spotboard-capture-confirmation",s.style.cssText=`
    position: fixed !important;
    top: 20px !important;
    right: 20px !important;
    background: #6b46c1 !important;
    color: white !important;
    padding: 20px !important;
    border-radius: 12px !important;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1) !important;
    z-index: 2147483647 !important;
    width: 340px !important;
    max-width: 90vw !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
    isolation: isolate !important;
  `,s.innerHTML=`
    <div style="margin-bottom: 16px;">
      <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${e.replace(/"/g,"&quot;")}">
        ✅ Captured: ${e}
      </div>
      <div style="font-size: 14px; opacity: 0.9;">
        Click elements inside the green box to exclude them.<br>
        They'll turn red. Click again to undo.
      </div>
    </div>
    <div style="margin-top: 12px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 12px;">
      <div id="advancedToggle" style="cursor: pointer; font-size: 13px; opacity: 0.8; user-select: none;">
        ⚙️ Advanced
      </div>
      <div id="advancedPanel" style="display: none; margin-top: 8px; font-size: 13px;">
        <div style="margin-bottom: 6px; opacity: 0.9;">Capture mode:</div>
        <label style="display: block !important; margin: 6px 0 !important; cursor: pointer !important; opacity: 0.95 !important;">
          <input type="radio" name="captureMode" value="header" ${a?"":"checked"} style="display: inline-block !important; margin-right: 6px !important; width: auto !important; height: auto !important; opacity: 1 !important; position: static !important;">
          <span style="display: inline !important; vertical-align: middle !important;">Header-based (uses section title)</span>
        </label>
        <label style="display: block !important; margin: 6px 0 !important; cursor: pointer !important; opacity: 0.95 !important;">
          <input type="radio" name="captureMode" value="position" ${a?"checked":""} style="display: inline-block !important; margin-right: 6px !important; width: auto !important; height: auto !important; opacity: 1 !important; position: static !important;">
          <span style="display: inline !important; vertical-align: middle !important;">Position-based (uses spot position on page)</span>
        </label>
      </div>
    </div>
    <div style="display: flex; gap: 8px; margin-top: 16px;">
      <button id="confirmSpot" style="flex: 1; padding: 12px; background: #48bb78; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
        Confirm Spot
      </button>
      <button id="cancelSpot" style="flex: 1; padding: 12px; background: #f56565; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
        Cancel
      </button>
    </div>
  `,document.body.appendChild(s);const f=document.getElementById("spotboard-capture-banner");f&&f.remove();const d=s.querySelector("#advancedToggle"),i=s.querySelector("#advancedPanel");d&&i&&d.addEventListener("click",()=>{const o=i.style.display==="block";i.style.display=o?"none":"block"});const l=s.querySelector("#confirmSpot");l&&l.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault();const c=(s.querySelector('input[name="captureMode"]:checked')?.value||"header")==="position";s.remove(),setTimeout(()=>{const u=[];E.forEach(P=>{const L=z(P);u.push(L)}),console.log("🎯 Generated",u.length,"exclusion selectors");const p=G(t,E);x("🧹 HTML sanitized, length:",p.length,"chars");const y=t.querySelector(`
          h1, h2, h3, h4, caption,
          [class*="heading"], [class*="title"], [class*="header"],
          [data-testid*="heading"], [data-testid*="title"]
        `)?.textContent?.trim()||null,C=y?y.substring(0,100):null,$=`https://www.google.com/s2/favicons?sz=64&domain=${new URL(window.location.href).hostname}`,b={id:crypto.randomUUID(),url:window.location.href,selector:n,name:e,html_cache:p,last_refresh:new Date().toISOString(),favicon:$},S={url:b.url,name:b.name,favicon:b.favicon,customLabel:void 0,selector:b.selector,headingFingerprint:C};console.log("💾 Storing metadata in sync storage (~300 bytes), exclusions in local storage");const F={[`comp-${b.id}`]:{id:b.id,name:S.name,url:S.url,favicon:S.favicon,customLabel:S.customLabel,selector:S.selector,headingFingerprint:S.headingFingerprint,positionBased:c,excludedSelectors:u,last_refresh:b.last_refresh}};chrome.storage.sync.set(F,()=>{if(chrome.runtime.lastError){console.error("❌ Sync storage set error:",chrome.runtime.lastError),k(`❌ Save failed: ${chrome.runtime.lastError.message}`,"error");return}chrome.storage.local.get(["componentsData"],P=>{if(chrome.runtime.lastError){console.error("❌ Local storage GET error:",chrome.runtime.lastError),k("❌ Save failed: Could not read local storage","error");return}const L=P.componentsData||{},_={selector:b.selector,html_cache:b.html_cache,last_refresh:b.last_refresh,excludedSelectors:u};L[b.id]=_,chrome.storage.local.set({componentsData:L},()=>{if(chrome.runtime.lastError){console.error("❌ Local storage set error:",chrome.runtime.lastError),k(`❌ Save failed: ${chrome.runtime.lastError.message}`,"error");return}chrome.storage.local.get(["componentsData"],I=>{const N=I.componentsData?.[b.id];!N||!N.html_cache?(console.error("❌ VERIFICATION FAILED: Component not found in local storage after save!"),console.error("   Component ID:",b.id),console.error("   Keys in storage:",Object.keys(I.componentsData||{})),k("⚠️ Warning: Save may have failed - please refresh dashboard","error")):console.log("✅ VERIFICATION PASSED: Component saved with",N.html_cache.length,"bytes HTML")}),t.style.outline="",t.style.cursor="",v=null,B(),k(`✅ Saved: ${e}`,"success"),T(!1)})})})},2e3)},!0);const m=s.querySelector("#cancelSpot");m&&m.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),s.remove(),t.style.outline="",t.style.cursor="",v=null,B(),T(!1)},!0);const g=o=>{o.key==="Escape"&&(s.remove(),t.style.outline="",t.style.cursor="",v=null,B(),document.removeEventListener("keydown",g))};document.addEventListener("keydown",g)}function U(t){t.key==="Escape"&&A&&(T(!1),alert("❌ Capture Cancelled"))}function Z(){if(document.getElementById("spotboard-capture-banner"))return;const t=document.createElement("div");t.id="spotboard-capture-banner",t.setAttribute("data-spotboard-ignore","true"),t.style.cssText=`
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    background: #FFFF00 !important;
    color: #000000 !important;
    padding: 10px 20px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 12px !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
    font-size: 14px !important;
    font-weight: 400 !important;
    z-index: 2147483646 !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;
    pointer-events: none !important;
  `,t.innerHTML=`
    <img src="${chrome.runtime.getURL("icon-16.png")}" style="width: 20px; height: 20px; pointer-events: none;">
    <span style="pointer-events: none;"><strong>Capture Mode Active</strong> - Click on any content you want to add to your board</span>
    <span style="margin-left: auto; pointer-events: none;">Press <span style="padding: 2px 6px; background: rgba(0, 0, 0, 0.15); border-radius: 3px; font-family: monospace; font-size: 12px;">[Esc]</span> to cancel capture</span>
  `,document.body.appendChild(t)}function T(t){if(A=t!==void 0?t:!A,A)document.addEventListener("mouseover",D,!0),document.addEventListener("mouseout",R,!0),document.addEventListener("click",M,!0),document.addEventListener("keydown",U,!0),Z();else{document.removeEventListener("mouseover",D,!0),document.removeEventListener("mouseout",R,!0),document.removeEventListener("click",M,!0),document.removeEventListener("keydown",U,!0),document.querySelectorAll("*").forEach(n=>{n.style.outline="",n.style.cursor=""});const e=document.getElementById("spotboard-capture-banner");e&&e.remove()}}chrome.runtime.onMessage.addListener((t,e,n)=>{(t.message==="TOGGLE_CAPTURE"||t.type==="TOGGLE_CAPTURE")&&T()});

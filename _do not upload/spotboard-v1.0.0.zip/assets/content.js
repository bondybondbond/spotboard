console.log("🚀 SpotBoard: Content Script Loaded");const q=!1,b=(...t)=>q;let S=!1,m=null,v=[];function N(t){return t?[/^yui_/i,/\d{10,}/,/[a-f0-9]{8}-[a-f0-9]{4}/i,/^react-/i,/^__BVID__/i,/^ember\d+/i].some(o=>o.test(t)):!1}function P(t){if(b("🎯 Starting selector generation for:",t.tagName,t.className),t.id&&!N(t.id))return b("✅ Found stable ID selector:",`#${t.id}`),`#${t.id}`;t.id&&N(t.id)&&b("⚠️ Skipping auto-generated ID:",t.id);let e=$(t);const o=document.querySelectorAll(e);if(b(`🔍 Base selector matches ${o.length} elements`),o.length===1)return e;b(`⚠️ Selector "${e}" matches ${o.length} elements, adding context...`),e===t.tagName.toLowerCase()&&o.length>50;const s=t.parentElement;if(s){const i=Array.from(s.children).filter(p=>p.matches(e.split("[")[0])).indexOf(t)+1;if(i>0){const p=`${e}:nth-of-type(${i})`,x=document.querySelectorAll(p);if(b(`🔍 nth-of-type selector matches ${x.length} elements`),x.length===1)return p}}const a=W(t,e);if(a)return a;if(/^[a-z]+$/i.test(e)){const l=t.parentElement;if(l)return`${$(l)} > ${e}`}return e}function U(t){return t.replace(/:/g,"\\:").replace(/\//g,"\\/").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/\(/g,"\\(").replace(/\)/g,"\\)").replace(/\./g,"\\.").replace(/#/g,"\\#").replace(/!/g,"\\!").replace(/@/g,"\\@").replace(/\$/g,"\\$").replace(/%/g,"\\%").replace(/\^/g,"\\^").replace(/&/g,"\\&").replace(/\*/g,"\\*").replace(/\+/g,"\\+").replace(/=/g,"\\=").replace(/,/g,"\\,").replace(/</g,"\\<").replace(/>/g,"\\>").replace(/\?/g,"\\?").replace(/~/g,"\\~")}function $(t){let e=t.tagName.toLowerCase();if(t.classList.length>0){const s=Array.from(t.classList).filter(a=>!a.includes("hover")&&!a.includes("active")).slice(0,3).map(a=>U(a));s.length>0&&(e+="."+s.join("."))}const o=["data-testid","data-test","data-component","data-section","data-module","data-type","data-t","role"];for(const s of o)if(t.hasAttribute(s)){const a=t.getAttribute(s);e+=`[${s}="${a}"]`;break}return e}function W(t,e){let o=t.parentElement;const s=[e];for(;o&&o.tagName!=="BODY"&&o.tagName!=="HTML";){if(o.id){s.unshift(`#${o.id}`);const i=s.join(" > ");if(document.querySelectorAll(i).length===1)return i}const a=["data-testid","data-component","data-section","data-module","data-type"];for(const i of a)if(o.hasAttribute(i)){const p=`${o.tagName.toLowerCase()}[${i}="${o.getAttribute(i)}"]`;s.unshift(p);const x=s.join(" > ");if(document.querySelectorAll(x).length===1)return x;s.shift()}const f=$(o);s.unshift(f);const l=s.join(" > ");if(document.querySelectorAll(l).length===1)return l;if(s.length>4)break;o=o.parentElement}return null}function B(t){if(!S)return;const e=t.target;if(!e.closest("#spotboard-capture-confirmation")){if(m){m.style.setProperty("outline","5px solid #00ff00","important"),m.contains(e)&&e!==m&&(v.includes(e)?(e.style.setProperty("background","rgba(255, 0, 0, 0.3)","important"),e.style.setProperty("outline","2px solid #ff0000","important")):(e.style.setProperty("outline","2px dashed #ff0000","important"),e.style.setProperty("background","transparent","important")),e.style.cursor="pointer");return}e.style.setProperty("outline","5px solid red","important"),e.style.cursor="crosshair",t.stopPropagation()}}function H(t){if(!S)return;const e=t.target;if(!e.closest("#spotboard-capture-confirmation")){if(m){if(e===m||v.includes(e))return;e.style.removeProperty("outline"),e.style.removeProperty("background");return}e.style.outline=""}}function k(t,e="success"){const o=document.createElement("div");o.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 999999;
  `;const s=document.createElement("div"),a=e==="success"?"#2d3748":"#742a2a";s.style.cssText=`
    background: ${a};
    color: white;
    padding: 24px;
    border-radius: 8px;
    max-width: 400px;
    width: 90%;
    text-align: center;
  `,s.innerHTML=`
    <div style="font-size: 16px; margin-bottom: 20px; line-height: 1.5;">
      ${t}
    </div>
    <button id="closeNotification" style="width: 100%; padding: 12px; background: #4299e1; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; font-weight: 600;">
      OK
    </button>
  `,o.appendChild(s),document.body.appendChild(o);const f=o.querySelector("#closeNotification");f&&f.addEventListener("click",()=>o.remove()),o.addEventListener("click",l=>{l.target===o&&o.remove()})}function _(t,e=[]){console.log("🧹 sanitizeHTML called with",e.length,"excluded elements");const o=[t,...Array.from(t.querySelectorAll("*"))],s=[],a=t.getBoundingClientRect(),f=r=>{let n=r.parentElement;for(;n&&n!==t;){const c=window.getComputedStyle(n),h=c.overflowX,u=c.overflow;if(u==="hidden"||u==="scroll"||u==="auto"||u==="clip"||h==="hidden"||h==="scroll"||h==="auto"||h==="clip"){const g=n.getBoundingClientRect();if(g.width<a.width&&g.width>50)return g}n=n.parentElement}return a};o.forEach(r=>{if(r instanceof HTMLElement&&r!==t){const n=window.getComputedStyle(r),c=n.display==="none",h=n.visibility==="hidden",u=n.opacity==="0",d=r.getAttribute("aria-hidden")==="true",g=r.getBoundingClientRect(),E=f(r),y=g.right<E.left,C=g.left>E.right;(c||h||u||d||(y||C))&&(r.setAttribute("data-spotboard-hidden","true"),s.push(r))}}),t.querySelectorAll("img").forEach(r=>{try{let n=r.closest("article, section")||r.parentElement;if(!n){console.log("  ⚠️ Image has no container, defaulting to icon"),r.setAttribute("data-scale-context","icon");return}const c=n.getBoundingClientRect(),h=c.width*c.height,u=r.getBoundingClientRect(),d=u.width*u.height,g=u.height,E=h>0?d/h:0;let y;g<40||d<1600?y="icon":g<70||d<4900||E<.1?y="small":E<.25||d<15e3?y="thumbnail":E<.5||d<4e4?y="medium":y="preview",r.setAttribute("data-scale-context",y)}catch(n){console.warn("  ⚠️ Failed to classify image, defaulting to icon:",n),r.setAttribute("data-scale-context","icon")}});const l=t.cloneNode(!0);s.forEach(r=>r.removeAttribute("data-spotboard-hidden")),e.length>0&&(console.log("🎯 Processing",e.length,"user-excluded elements"),e.forEach(r=>{const n=D(r,t);console.log("  📍 Excluded element path:",n,r.tagName,r.className);const c=M(l,n);c?(c.remove(),console.log("  ✅ Removed excluded element from clone")):console.warn("  ⚠️ Could not find excluded element in clone")})),[".visually-hidden",".sr-only",'[class*="VisuallyHidden"]','[class*="MobileValue"]','[class*="-mobile"]','[class*="mobile-"]','[class*="-short"]','[class*="short-"]','[class*="team-name--short"]','[class*="team-name--abbr"]','[class*="-abbr"]','[class*="abbreviated"]','[class*="navigate"]','[class*="NavigateButton"]','[class*="previousButton"]','[class*="nextButton"]','[class*="prevButton"]','[class*="Chevron"]','[class*="chevron"]','[class*="carousel-control"]','[class*="slick-arrow"]','[class*="swiper-button"]','[class*="gallery-nav"]','[class*="slider-nav"]','[class*="slide-arrow"]','button[aria-label*="previous"]','button[aria-label*="next"]','button[aria-label*="arrow"]','[class*="ImageControls"]','[class*="image-controls"]','[class*="Controls_"]'].forEach(r=>{l.querySelectorAll(r).forEach(n=>n.remove())}),l.querySelectorAll('[data-spotboard-hidden="true"]').forEach(r=>r.remove()),[l,...Array.from(l.querySelectorAll("*"))].forEach(r=>{r instanceof HTMLElement&&(r.style.removeProperty("cursor"),r.style.removeProperty("outline"),r.style.length===0&&r.removeAttribute("style"))}),l.querySelectorAll("img").forEach(r=>{r.removeAttribute("loading"),["blurring","skeleton","loading","placeholder","lazy","lazy-load"].forEach(c=>{r.classList.contains(c)&&r.classList.remove(c)})}),l.querySelectorAll("img").forEach(r=>{const n=["data-image","data-src","data-lazy-src","data-original","data-lazy"];for(const c of n){const h=r.getAttribute(c);if(h&&h.startsWith("http")){r.setAttribute("src",h);break}}});const w=window.location.href;return l.querySelectorAll("img[src]").forEach(r=>{const n=r.getAttribute("src");if(n&&n.startsWith("//")){r.setAttribute("src","https:"+n);return}if(n&&!n.startsWith("http")&&!n.startsWith("data:")&&!n.startsWith("blob:"))try{const c=new URL(n,w).href;r.setAttribute("src",c)}catch(c){console.warn("  ⚠️ Could not fix img src:",n,c)}}),l.querySelectorAll("img[srcset]").forEach(r=>{const n=r.getAttribute("srcset");if(n)try{const c=n.split(",").map(h=>{const u=h.trim().split(/\s+/),d=u[0];if(d&&d.startsWith("//"))return u[0]="https:"+d,u.join(" ");if(d&&!d.startsWith("http")&&!d.startsWith("data:")&&!d.startsWith("blob:")){const g=new URL(d,w).href;u[0]=g}return u.join(" ")}).join(", ");r.setAttribute("srcset",c)}catch(c){console.warn("  ⚠️ Could not fix img srcset:",c)}}),l.querySelectorAll("a[href]").forEach(r=>{const n=r.getAttribute("href");if(n&&!n.startsWith("#")&&!n.startsWith("javascript:")&&!n.startsWith("mailto:")&&!n.startsWith("tel:")&&!n.startsWith("http"))try{const c=new URL(n,w).href;r.setAttribute("href",c)}catch(c){console.warn("  ⚠️ Could not fix link href:",n,c)}}),l.querySelectorAll("[style]").forEach(r=>{const n=r.getAttribute("style");if(n&&n.includes("url("))try{const c=n.replace(/url\(['"]?([^'"()]+)['"]?\)/g,(h,u)=>{if(u.startsWith("data:")||u.startsWith("blob:")||u.startsWith("http"))return h;try{return`url('${new URL(u,w).href}')`}catch{return h}});r.setAttribute("style",c)}catch(c){console.warn("  ⚠️ Could not fix CSS background:",c)}}),l.outerHTML}function D(t,e){const o=[];let s=t;for(;s&&s!==e;){const a=s.parentElement;if(!a)break;const f=Array.from(a.children).indexOf(s);o.unshift(f),s=a}return o}function M(t,e){let o=t;for(const s of e){if(!o)return null;o=o.children[s]||null}return o}function T(){v.forEach(t=>{t.style.removeProperty("background"),t.style.removeProperty("outline")}),v=[]}function I(t){if(v.includes(t))v=v.filter(o=>o!==t),t.style.removeProperty("background"),t.style.removeProperty("outline"),b("✅ Element un-excluded:",t.tagName,t.className);else{const o=P(t);if(/^[a-z]+$/i.test(o.trim())){const i=document.createElement("div");i.style.cssText=`
        position: absolute;
        background: #f56565;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        z-index: 999998;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        pointer-events: none;
      `,i.textContent="⚠️ Too generic - will be skipped!";const p=t.getBoundingClientRect();i.style.left=`${p.left+window.scrollX}px`,i.style.top=`${p.top+window.scrollY-40}px`,document.body.appendChild(i),setTimeout(()=>i.remove(),3e3)}const a=/^H[1-6]$/i.test(t.tagName),f=t.className&&(t.className.includes("heading")||t.className.includes("title")||t.className.includes("header")),l=t.hasAttribute("data-testid")&&(t.getAttribute("data-testid")?.includes("heading")||t.getAttribute("data-testid")?.includes("title"));if(a||f||l){const i=document.createElement("div");i.style.cssText=`
        position: absolute;
        background: #f59e0b;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        z-index: 999998;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        pointer-events: none;
        max-width: 280px;
        line-height: 1.4;
      `,i.innerHTML="⚠️ Excluding heading may affect refresh.<br>Keep section labels for best results.";const p=t.getBoundingClientRect();i.style.left=`${p.left+window.scrollX}px`,i.style.top=`${p.top+window.scrollY-60}px`,document.body.appendChild(i),setTimeout(()=>i.remove(),4e3)}v.push(t),t.style.setProperty("background","rgba(255, 0, 0, 0.3)","important"),t.style.setProperty("outline","2px solid #ff0000","important"),b("❌ Element excluded:",t.tagName,t.className)}}function R(t){if(!S)return;b("🖱️ Click detected on:",t.target);const e=t.target;if(e.closest("#spotboard-capture-confirmation"))return;if(m){if(m.contains(e)&&e!==m){t.preventDefault(),t.stopPropagation(),I(e);return}return}t.preventDefault(),t.stopPropagation(),b("🎯 Target element:",e.tagName,e.className),m=e,e.style.setProperty("outline","5px solid #00ff00","important");let o="";if(/^H[1-6]$/i.test(e.tagName)){const a=e.textContent?.trim();a&&(o=a.length>50?a.substring(0,50)+"...":a)}if(!o){const a=e.querySelector("h1, h2, h3, h4, h5, h6");if(a?.textContent?.trim()){const f=a.textContent.trim();o=f.length>50?f.substring(0,50)+"...":f}}if(!o){const f=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:l=>{const i=l.textContent?.trim();return i&&i.length>0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}}).nextNode();if(f?.textContent?.trim()){const l=f.textContent.trim();o=l.length>50?l.substring(0,50)+"...":l}}o||(o=`Spot from ${window.location.hostname}`);const s=P(e);O(e,o,s)}function O(t,e,o){const s=document.createElement("div");s.id="spotboard-capture-confirmation",s.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    background: #6b46c1;
    color: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    z-index: 999999;
    min-width: 300px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  `,s.innerHTML=`
    <div style="margin-bottom: 16px;">
      <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">
        ✅ Captured: ${e}
      </div>
      <div style="font-size: 14px; opacity: 0.9;">
        Click elements inside the green box to exclude them.<br>
        They'll turn red. Click again to undo.
      </div>
    </div>
    <div style="display: flex; gap: 8px;">
      <button id="confirmSpot" style="flex: 1; padding: 12px; background: #48bb78; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
        Confirm Spot
      </button>
      <button id="cancelSpot" style="flex: 1; padding: 12px; background: #f56565; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
        Cancel
      </button>
    </div>
  `,document.body.appendChild(s);const a=s.querySelector("#confirmSpot");a&&a.addEventListener("click",i=>{i.stopPropagation(),i.preventDefault(),s.remove(),setTimeout(()=>{const p=[];v.forEach(C=>{const A=P(C);p.push(A)}),console.log("🎯 Generated",p.length,"exclusion selectors");const x=_(t,v);b("🧹 HTML sanitized, length:",x.length,"chars");const w=document.createElement("div");w.innerHTML=x;const n=w.querySelector(`
          h1, h2, h3, h4,
          [class*="heading"], [class*="title"], [class*="header"],
          [data-testid*="heading"], [data-testid*="title"]
        `)?.textContent?.trim()||null,c=n?n.substring(0,100):null,u=`https://www.google.com/s2/favicons?sz=64&domain=${new URL(window.location.href).hostname}`,d={id:crypto.randomUUID(),url:window.location.href,selector:o,name:e,html_cache:x,last_refresh:new Date().toISOString(),favicon:u},g={url:d.url,name:d.name,favicon:d.favicon,customLabel:void 0,selector:d.selector,headingFingerprint:c};console.log("💾 Storing metadata in sync storage (~300 bytes), exclusions in local storage");const y={[`comp-${d.id}`]:{id:d.id,name:g.name,url:g.url,favicon:g.favicon,customLabel:g.customLabel,selector:g.selector,headingFingerprint:g.headingFingerprint,excludedSelectors:p,last_refresh:d.last_refresh}};chrome.storage.sync.set(y,()=>{if(chrome.runtime.lastError){console.error("❌ Sync storage set error:",chrome.runtime.lastError),k(`❌ Save failed: ${chrome.runtime.lastError.message}`,"error");return}chrome.storage.local.get(["componentsData"],C=>{const A=C.componentsData||{};A[d.id]={selector:d.selector,html_cache:d.html_cache,last_refresh:d.last_refresh,excludedSelectors:p},chrome.storage.local.set({componentsData:A},()=>{if(chrome.runtime.lastError){console.error("❌ Local storage set error:",chrome.runtime.lastError),k(`❌ Save failed: ${chrome.runtime.lastError.message}`,"error");return}t.style.outline="",t.style.cursor="",m=null,T(),k(`✅ Saved: ${e}`,"success"),L(!1)})})})},2e3)},!0);const f=s.querySelector("#cancelSpot");f&&f.addEventListener("click",i=>{i.stopPropagation(),i.preventDefault(),s.remove(),t.style.outline="",t.style.cursor="",m=null,T(),L(!1)},!0);const l=i=>{i.key==="Escape"&&(s.remove(),t.style.outline="",t.style.cursor="",m=null,T(),document.removeEventListener("keydown",l))};document.addEventListener("keydown",l)}function z(t){t.key==="Escape"&&S&&(L(!1),alert("❌ Capture Cancelled"))}function L(t){S=t!==void 0?t:!S,S?(document.addEventListener("mouseover",B,!0),document.addEventListener("mouseout",H,!0),document.addEventListener("click",R,!0),document.addEventListener("keydown",z,!0)):(document.removeEventListener("mouseover",B,!0),document.removeEventListener("mouseout",H,!0),document.removeEventListener("click",R,!0),document.removeEventListener("keydown",z,!0),document.querySelectorAll("*").forEach(e=>{e.style.outline="",e.style.cursor=""}))}chrome.runtime.onMessage.addListener((t,e,o)=>{(t.message==="TOGGLE_CAPTURE"||t.type==="TOGGLE_CAPTURE")&&L()});
